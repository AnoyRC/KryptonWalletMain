export default function NFTs() {
  return <></>;
}

export const metadata = {
  title: 'Krypton | Home',
  description: 'By Bankless DAO',
};

export default function LandingLayout({ children }) {
  return <>{children}</>;
}

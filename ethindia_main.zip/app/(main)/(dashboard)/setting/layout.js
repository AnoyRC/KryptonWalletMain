export const metadata = {
  title: 'Krypton | Setting',
  description: 'By Bankless DAO',
};

export default function LandingLayout({ children }) {
  return <>{children}</>;
}

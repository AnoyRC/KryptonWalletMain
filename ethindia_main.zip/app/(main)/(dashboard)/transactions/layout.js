export const metadata = {
  title: 'Krypton | Transactions',
  description: 'By Bankless DAO',
};

export default function LandingLayout({ children }) {
  return <>{children}</>;
}

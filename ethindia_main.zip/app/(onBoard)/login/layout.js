export const metadata = {
  title: "Krypton | Login",
  description: "By Bankless DAO",
};

export default function SetupLayout({ children }) {
  return <>{children}</>;
}

export const metadata = {
  title: "Krypton | Setup",
  description: "By Bankless DAO",
};

export default function LoginLayout({ children }) {
  return <>{children}</>;
}
